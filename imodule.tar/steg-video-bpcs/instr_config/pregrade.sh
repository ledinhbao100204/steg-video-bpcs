#!/bin/bash
homedir=$1
destdir=$2
dbg=/tmp/pregrade.log
cd "$homedir/$destdir"

outpath=.local/result
outfile=$outpath/message_compare.txt
mkdir -p "$outpath"
echo "messages differ" > "$outfile"

if [ -f extracted_message.txt ] && [ -f expected_message.txt ]; then
   if cmp -s extracted_message.txt expected_message.txt; then
      echo "messages match" > "$outfile"
   fi
fi

echo "pregrade complete for $destdir" >> "$dbg"
